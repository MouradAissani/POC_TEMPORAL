﻿namespace POC_TEMPORAL_WEB.Models;

public class JwtSettings
{
    public string Token { get; set; } = string.Empty;
}