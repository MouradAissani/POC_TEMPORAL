﻿namespace POC_TEMPORAL_WEB.Models;

public class HttpClientSettings
{
    public string BaseAddress { get; set; }
}
