﻿namespace POC_TEMPORAL_WEB.Models;

public class TemporalSettings
{
    public string Namespace { get; set; } = string.Empty;
    public string Server { get; set; } = string.Empty;
}
