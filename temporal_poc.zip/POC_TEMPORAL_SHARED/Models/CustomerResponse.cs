﻿namespace POC_TEMPORAL_SHARED.Models
{
    public class CustomerResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }

}
