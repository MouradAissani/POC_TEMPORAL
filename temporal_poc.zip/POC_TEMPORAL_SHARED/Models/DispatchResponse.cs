﻿namespace POC_TEMPORAL_SHARED.Models;

public class DispatchResponse
{
    public int StatusCode { get; set; }
    public string Message { get; set; }
}